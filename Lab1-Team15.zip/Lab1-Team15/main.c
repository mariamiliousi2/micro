#include <stdio.h>
#include <stdint.h>
#include <string.h>  
// Correct function prototype
extern void hash_calc_2(char *str, int *hash); // `hash` is a pointer, not a value
extern void sum_mod7_2(int hash, int *mod_value);
extern void fibonacci_2(int mod_value,int *fib_value);

int main() {
    char input[100];
	  printf("Enter a string: ");
    scanf("%s",input);
    printf("Input: %s\n", input);

    int hash;
    hash_calc_2(input, &hash);  // Pass address of `hash`
    printf("Hash: %u\n", hash);
	  
	  int mod_value;
	  sum_mod7_2(hash,&mod_value);
	  printf("Mod: %u\n",mod_value);
	  
	  int fib_value;
	  fibonacci_2(mod_value,&fib_value);
	  printf("Fib: %u\n",fib_value); 
	
    return 0;
}
